<?php $__env->startSection('content'); ?>
  <div class="formulario formregistro">
    <div class="tituloForm">
      INGRESA CON TUS DATOS
    </div>
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
      <input id="email" type="email" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>"  required autocomplete="email" autofocus placeholder="Email">
        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

       <input id="password" type="password" class=" <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" placeholder="Contraseña">
         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
             <div class="invalid-feedback" role="alert">
                 <strong><?php echo e($message); ?></strong>
             </div>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

         <div>

           <button class="boton" type="reset" name="borrar">BORRAR</button>
           <button class="boton" type="submit" name="enviar">ENTRAR</button>
           <div class="rememberMe">
          <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
          <label for="remember" class="email">Recordarme</label>
          </div>

        </div>
  <a href="<?php echo e(route('register')); ?>"> <div class="cabecera">¿AÚN NO ESTÁS REGISTRADO?</div></a>
  <div>
  <?php if(Route::has('password.request')): ?>
      <a href="<?php echo e(route('password.request')); ?>">
          <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

      </a>
  <?php endif; ?>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/auth/login.blade.php ENDPATH**/ ?>