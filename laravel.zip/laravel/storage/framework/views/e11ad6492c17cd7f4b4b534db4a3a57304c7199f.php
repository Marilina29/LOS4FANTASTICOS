<?php $__env->startSection('content'); ?>

<div class="contenItem">
  
  <div class="baseItem listaCompra">

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h3 class="numCompra">N° de compra: <?php echo e($items[0]->order_number); ?></h3>
<div class="conjComprados">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="prodComprado"><img class="imagProdComprado" src="/storage/imagenes/<?php echo e($item->img); ?>" alt="">
          </div>
          <div class="dataComprado">
            Producto: <?php echo e($item->name); ?>

            <br>Precio: <?php echo e($item->price); ?>

            <br>Cantidad: <?php echo e($item->cant); ?>


          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/perfil.blade.php ENDPATH**/ ?>