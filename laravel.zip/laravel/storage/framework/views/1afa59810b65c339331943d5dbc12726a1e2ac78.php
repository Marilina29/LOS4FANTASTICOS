<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'glassbeat')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <script src="<?php echo e(asset('js/java.js')); ?>" defer></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed:400,500&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/62ba28ee55.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Styles -->

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
  <header>


<div class="topnav" id="myTopnav">
    <a class="logo active" href="/"> <img src="/imagenes/glassBeat-logo.png" width="150" height="50"  alt="GlassBeat"> </a>
<a class="aheader" href="/lista-productos"> SHOP </a>
<a class="aheader" href="/historia"> HISTORIA </a>
 <a class="aheader" href="mailto:marilina_29@hotmail.com"> CONTACTO </a>
<a class="aheader" href="index.php#envios"> ENVIOS </a>

      <a href="javascript:void(0);" class="icon" onclick="myFunction()"><i class="fa fa-bars"></i></a>


</div>


    <ul class="uliconos">

      <li class="naviconos"> <a href="#">
        <i class="colorb fas fa-user-circle"></i></a>
        <ul class="dropdown">

        <?php if(auth()->guard()->guest()): ?>
                    <li><a class="logs" href="<?php echo e(route('login')); ?>">LOGIN</a></li>
        <?php if(Route::has('register')): ?>
                    <li><a class="logs" href="<?php echo e(route('register')); ?>">REGISTRATE</a></li>
        <?php endif; ?>
        <?php else: ?>

<li><a <a id="navbarDropdown" class="logs" href="/perfil" role="button">
    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
</a></li>
<li><a class="logs" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
 <?php echo e(__('SALIR')); ?>

</a>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>
              </li>
          <?php endif; ?>
                </ul>
      </li>
      <li class="naviconos"> <a href="#"><i class="colorb fas fa-search"></i></a>
        <ul class="dropdown search">
        <form class="" action="/buscador" method="GET">
          <?php echo csrf_field(); ?>
          <div>
            <input style="width: 171px; height: 25px; font-size: 16px"; type="text" name="search" value="">
          </div>
          <button type="submit" style="display:none"></button>
        </form>
        </ul>
       </li>

    <?php if(!Auth::guest()): ?>
        <li>
          <a  class="naviconos" href="/carrito">
          <i class=" colorb fas fa-shopping-bag"></i></a>
        </li>
      <?php else: ?>
        <li>
          <a class="naviconos" href="<?php echo e(route('login')); ?>">
            <i class="colorb fas fa-shopping-bag"></i>
          </a>
        </li>
      <?php endif; ?>
    </ul>
  </header>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <footer>
      <ul>
        <li> <a href="https://www.instagram.com/glassbeatart/"><i class="fab fa-instagram"></i></a> </li>
        <li> <a href="https://www.facebook.com/GlassBeatArt/"><i class="fab fa-facebook"></i> </a> </li>
        <li> <a href="mailto:marilina_29@hotmail.com"> <i class="fas fa-paper-plane"></i></a> </li>
      </ul>
    </footer>


    </script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>