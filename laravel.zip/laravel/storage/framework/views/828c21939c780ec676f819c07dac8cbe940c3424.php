<?php $__env->startSection('content'); ?>

  <div class="formulario formregistro">
    <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="tituloForm">
        REGISTRATE AQUÍ
      </div>
        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Nombre">
          <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
              <div class="errores" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>



        <input id="surname" type="text" class="form-control <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="surname" value="<?php echo e(old('surname')); ?>" required autocomplete="surname" autofocus placeholder="Apellido">
          <?php if ($errors->has('surname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('surname'); ?>
              <div class="errores" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


        <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email">
          <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
              <div class="errores" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <input id="dni" type="integer" class="form-control <?php if ($errors->has('dni')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dni'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="dni" value="<?php echo e(old('dni')); ?>" required autocomplete="dni" placeholder="DNI">
        <?php if ($errors->has('dni')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dni'); ?>
          <div class="errores" role="alert">
                <strong><?php echo e($message); ?></strong>
          </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

        <input id="telephone" type="integer" class="form-control <?php if ($errors->has('telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telephone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="telephone" value="<?php echo e(old('telephone')); ?>" required autocomplete="telephone" placeholder="Teléfono">
        <?php if ($errors->has('telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telephone'); ?>
          <div class="errores" role="alert">
                <strong><?php echo e($message); ?></strong>
          </div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password" placeholder="Contraseña">
          <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
              <div class="errores" role="alert">
                  <strong><?php echo e($message); ?></strong>
              </div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


          <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirmar Contraseña">



        <p class="salto"></p>
        <button class="boton" type="reset" name="button">BORRAR</button>
        <button class="boton" type="submit" name="button">ENVIAR</button>
        <a href="<?php echo e(route('login')); ?>"> <div class="cabecera" name="button">¿YA ESTÁS REGISTRADO? INGRESA <strong>AQUÍ</strong></div></a>
    </form>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/auth/register.blade.php ENDPATH**/ ?>