<?php $__env->startSection('content'); ?>


<div class="contenItem">
  <div class="baseCarrito">
    <div>
      <?php
        $total = 0;
      ?>
      <table>

        <tr class="itemCarro">
          <td class="tdImagen">Imagen</td>
          <td class="tdNombre"> Producto</td>
          <td class="tdPrecio1">Precio</td>
          <td class="tdCantidad">Cantidad</td>

          <td class="tdPrecio">Total</td>
        </tr>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="itemCarro">
          <td class="tdImagen"><img src="/storage/imagenes/<?php echo e($order->img); ?>" alt=""></td>
          <td class="tdNombre"> <h3><?php echo e($order->name); ?></h3></td>
          <td class="tdPrecio1">$ <?php echo e($order->price); ?></td>
          <td class="tdCantidad">

          <form class="" action="/sacarCarrito" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
            <button class="eliminoSumo" type="submit" name="button">-</button>
          </form>

          <?php echo e($order->cant); ?>


          <form class="" action="/masUno" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value=<?php echo e($order->id); ?>>
            <button class="eliminoSumo" type="submit" name="button">+</button>
          </form>

        </td>

          <td class="tdPrecio">$ <?php echo e($order->price * $order->cant); ?></td>

        </tr>

          <?php
            $total += $order->price * $order->cant;
          ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="cierreCarro">
            TOTAL: <?php echo e($total); ?>

          </td>
        </tr>
      <tr>
        <td class="finCarrito">
          <a href="/lista-productos"><button class="finalCarro" type="button" name="button">SEGUIR COMPRANDO</button></a>
          <form class="" action="/cartclose" method="post">
            <?php echo csrf_field(); ?>
            <button class="finalCarro" type="submit" name="button">PAGAR</button>
          </form>
        </td>
        </tr>
      </table>

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/carrito.blade.php ENDPATH**/ ?>