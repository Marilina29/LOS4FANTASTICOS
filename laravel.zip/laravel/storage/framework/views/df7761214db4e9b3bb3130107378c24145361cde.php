<?php $__env->startSection('title'); ?>
  Ficha de Producto
<?php $__env->stopSection(); ?>
<?php $__env->startSection('h1', "Su producto"); ?>

<?php $__env->startSection('content'); ?>
  <div class="marginados">
      <img class="destacadosHome" src="/storage/imagenes/<?php echo e($product->img); ?>" alt="IMAGEN DE PRODUCTO"> <p class="nombreDestacado" > <?php echo e($productDetail->name); ?></p>
      <p class="nombreDestacado" > <?php echo e($productDetail->description); ?></p>
      <p>
    <span class="precio"> <?php echo e($productDetail->price); ?> </span> <br> </p>
    <button class="botonComprar" type="button" name="button">COMPRAR</button>

      <p> <a href="/lista-productos">Volver</a> </p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/product.blade.php ENDPATH**/ ?>