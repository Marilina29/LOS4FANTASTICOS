<?php $__env->startSection('title'); ?>
  Lista de Productos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('h1', "Lista de productos"); ?>

<?php $__env->startSection('content'); ?>
  <aside>
    <ul>
      <li><a href="/lista-productos">Todos</a></li>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="/category/<?php echo e($value->id); ?>"><?php echo e($value->name); ?></a></li>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </ul>
  </aside>
  <div class="mainProds marginados">
    <div class="ultimasCreaciones uCProducto">
          <div class="conjuntoUCproductos">
  <ul class="listita">
        <?php for($i=0; $i < count($products); $i++): ?>
          <div class="cajaProductos">
          <a href="/vistaProducto/<?php echo e($products[$i]->id); ?>"> <img class="destacadosHome" src="/storage/imagenes/<?php echo e($products[$i]->img); ?>" alt="IMAGEN DE PRODUCTO"> <p class="nombreDestacado" > <?php echo e($products[$i]->name); ?>

          <span class="precio"> <?php echo e($products[$i]->price); ?> </span> <br> </p>
          <a href="/vistaProducto/<?php echo e($products[$i]->id); ?>"> <button class="botonComprar" type="button" name="button">VER MÁS</button></a> </a></div>
        <?php endfor; ?>
      </ul>

        <?php echo e($products->links()); ?>


    </div>

  </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/products.blade.php ENDPATH**/ ?>