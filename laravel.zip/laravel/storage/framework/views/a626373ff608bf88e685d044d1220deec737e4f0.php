<?php $__env->startSection('content'); ?>
<div class="contenItem">
      <a href="/lista-productos"><button class="cerrarItem" type="button" name="button"><i class="fas fa-times"></i></button></a>
  <div class="baseItem">
  <div class="imagItem">
    <img src="/storage/imagenes/<?php echo e($product->img); ?>" alt="<?php echo e($product->name); ?>">
  </div>
  <div class="imagItem">
    <h6><?php echo e($product->name); ?></h6>
    <hr>
    <div class="descrItem">
      <p><?php echo e($product->description); ?></p>
    </div>
  </div>
  <div class="precioItem">
    Precio: $ <?php echo e($product->price); ?>

  </div>
  </div>
  <div class="botSumarItem">
    <form class="" action="/agregarCarrito" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value=<?php echo e($product->id); ?>>
      <button class="sumarItem" type="submit" name="button">AGREGAR AL CARRITO</button>
    </form>
  </div>
</div>
<div class="botSumarItem">
  <?php if(Auth::user()->rol == 100): ?>
      <form class="" action="/eliminoProducto" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value=<?php echo e($product->id); ?>>
        <button class="admin eliminoProd" type="submit" name="button">ELIMINO PRODUCTO</button>
      </form>

      <a href="/agregoProducto">
        <button class="admin" type="submit" name="button">AGREGAR PRODUCTO</button>
      </a>
  <?php endif; ?>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/LOS4FANTASTICOS/laravel/resources/views/vistaProducto.blade.php ENDPATH**/ ?>