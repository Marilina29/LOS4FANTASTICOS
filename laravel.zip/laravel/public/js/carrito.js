

console.log('hola');
var quitar = document.querySelector('.botonQuitar');

quitar.onclick = function() {
  var respuesta = confirm("Desea quitar el producto de su carrito?");
}
