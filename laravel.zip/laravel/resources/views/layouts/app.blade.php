<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'glassbeat') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
  <script src="{{ asset('js/java.js') }}" defer></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Barlow+Condensed:400,500&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/62ba28ee55.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Styles -->

    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
</head>
<body>
  <header>


<div class="topnav" id="myTopnav">
    <a class="logo active" href="/"> <img src="/imagenes/glassBeat-logo.png" width="150" height="50"  alt="GlassBeat"> </a>
<a class="aheader" href="/lista-productos"> SHOP </a>
<a class="aheader" href="/historia"> HISTORIA </a>
 <a class="aheader" href="mailto:marilina_29@hotmail.com"> CONTACTO </a>
<a class="aheader" href="index.php#envios"> ENVIOS </a>

      <a href="javascript:void(0);" class="icon" onclick="myFunction()"><i class="fa fa-bars"></i></a>


</div>


    <ul class="uliconos">

      <li class="naviconos"> <a href="#">
        <i class="colorb fas fa-user-circle"></i></a>
        <ul class="dropdown">

        @guest
                    <li><a class="logs" href="{{ route('login') }}">LOGIN</a></li>
        @if (Route::has('register'))
                    <li><a class="logs" href="{{ route('register') }}">REGISTRATE</a></li>
        @endif
        @else

<li><a <a id="navbarDropdown" class="logs" href="/perfil" role="button">
    {{ Auth::user()->name }} <span class="caret"></span>
</a></li>
<li><a class="logs" href="{{ route('logout') }}" onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
 {{ __('SALIR') }}
</a>
<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                          @csrf
                      </form>
              </li>
          @endguest
                </ul>
      </li>
      <li class="naviconos"> <a href="#"><i class="colorb fas fa-search"></i></a>
        <ul class="dropdown search">
        <form class="" action="/buscador" method="GET">
          @csrf
          <div>
            <input style="width: 171px; height: 25px; font-size: 16px"; type="text" name="search" value="">
          </div>
          <button type="submit" style="display:none"></button>
        </form>
        </ul>
       </li>

    @if (!Auth::guest())
        <li>
          <a  class="naviconos" href="/carrito">
          <i class=" colorb fas fa-shopping-bag"></i></a>
        </li>
      @else
        <li>
          <a class="naviconos" href="{{ route('login') }}">
            <i class="colorb fas fa-shopping-bag"></i>
          </a>
        </li>
      @endif
    </ul>
  </header>

        <main>
            @yield('content')
        </main>
    </div>
    <footer>
      <ul>
        <li> <a href="https://www.instagram.com/glassbeatart/"><i class="fab fa-instagram"></i></a> </li>
        <li> <a href="https://www.facebook.com/GlassBeatArt/"><i class="fab fa-facebook"></i> </a> </li>
        <li> <a href="mailto:marilina_29@hotmail.com"> <i class="fas fa-paper-plane"></i></a> </li>
      </ul>
    </footer>


    </script>
</body>
</html>
