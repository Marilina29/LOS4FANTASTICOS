@extends('layouts.app')

@section('content')

<div class="contenItem">
  <div class="envios">
    <h2>Transformando energía en creación</h2>
    <p class="marginados">En Agosto de 2013, después de mucha búsqueda, encontré quien pudiera darme las herramientas para materializar mi pasión por el vidrio.</p>
    <p>
    Desde entonces no pierdo la oportunidad de ir al taller, a transmutar energía creativa y materializar mis ideas en piezas de vidrio únicas que llenan mi alma de alegría. Y con suerte llenarán también la tuya.
    </p>
  </div>

<img class="imagHistoria" src="imagenes/baner1-1580x500.jpg" alt="">
</div>

</div>

@endsection
